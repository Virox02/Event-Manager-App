<?php
 

include 'dbconfig.php';
 
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
$name = $obj['name'];
$email = $obj['email'];
$password = $obj['password'];

$class = $obj['class'];
$section = $obj['section'];
$phone = $obj['phone'];
$role = $obj['role'];
$type = $obj['type'];
$otp = $obj['otp'];

$CheckSQL = "SELECT * FROM user WHERE email='$email'";
$check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
 
 
if(isset($check)){
    $EmailExistMSG = ['status'=>'500','message'=>'Email Already Exist, Please Try Again !!!'];
    $EmailExistJson = json_encode($EmailExistMSG);
    echo $EmailExistJson ; 
 
}else{
    if($type == '2'){
        $CheckTeacherSql = "SELECT * FROM teacher_email WHERE teacherEmail='$email'";
        $CheckTeacher = mysqli_fetch_array(mysqli_query($con,$CheckTeacherSql));
        if(!empty($CheckTeacher)){
            $Sql_Query = "insert into user (name,email,class,section,password,role,otp,type) values ('$name','$email','$class','$section','$password','$role','$otp','$type')";
            if(mysqli_query($con,$Sql_Query)){
                $MSG = ['status'=>'200','message'=>'Teacher Registered Successfully'];
                $json = json_encode($MSG);
                echo $json ;
            }else{
                $MSG = ['status'=>'500','message'=>'Teacher Not Added Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
            }        
        }else{
            $MSG = ['status'=>'500','message'=>'Teacher Email Address Not Registered Inside System'];
            $json = json_encode($MSG);
            echo $json ;
        }
    }else{
        $Sql_Query = "insert into user (name,email,class,section,password,role,otp,type) values ('$name','$email','$class','$section','$password','$role','$otp','$type')";
        if(mysqli_query($con,$Sql_Query)){
            $MSG = ['status'=>'200','message'=>'Student Registered Successfully'];
            $json = json_encode($MSG);
            echo $json ;
        }else{
            $MSG = ['status'=>'500','message'=>'Student Not Added Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
        }
    }
        
}
 mysqli_close($con);
?>