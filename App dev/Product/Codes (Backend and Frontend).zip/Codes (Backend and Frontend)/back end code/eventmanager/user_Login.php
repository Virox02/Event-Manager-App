<?php
 
include 'dbconfig.php';
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
 

$email = $obj['email'];
$password = $obj['password'];

$Sql_Query = "select * from user where email = '$email' AND is_delete = 0";
$check = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
// echo $check;die;
if(isset($check)){
    $is_verified = $check['verified'];
    if($is_verified != 1){
        $InvalidMSG = ['status'=>'500','message'=>'Email Authenticcation has not been done yet'];
        $InvalidMSGJSon = json_encode($InvalidMSG);
        echo $InvalidMSGJSon ;
    }else{
        $password_checker = "select * from user where email = '$email' and password = '$password' ";
        // $InvalidMSGJSon = json_encode($password_checker);
        // echo $password_checker ;die;
        $check_password = mysqli_fetch_array(mysqli_query($con,$password_checker));
        if(isset($check_password)){
            $SuccessLoginMsg = ['status'=>'200','message'=>'Data Matched','data'=>$check_password];
            $SuccessLoginJson = json_encode($SuccessLoginMsg);
            echo $SuccessLoginJson ;
        }else{
            $InvalidMSG = ['status'=>'500','message'=>'Invalid Password, Please Try Again'];
            $InvalidMSGJSon = json_encode($InvalidMSG);
            echo $InvalidMSGJSon ;
        }
    }    
}else{
    $InvalidMSG = ['status'=>'500','message'=>'Email id is not registered with us Please Try Again'];
    $InvalidMSGJSon = json_encode($InvalidMSG);
    echo $InvalidMSGJSon ;
}
 
mysqli_close($con);
?>