<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception; 

require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
include 'dbconfig.php';
 
$mail = new PHPMailer(true);
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
 

$email = $obj['email'];

$Sql_Query = "select email from user where email = '$email'";
$check = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
if(!empty($check)){
    $Sql_Query = "select password from user where email = '$email'";
    $check = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
    if($check){
        $password = $check['password']; 
    }
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'virox0220@gmail.com';
        $mail->Password   = 'virajrahil02';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;
    
        $mail->setFrom('virox0220@gmail.com', 'JPIS');
        $mail->addAddress($email);
        
        $mail->isHTML(true);
        $mail->Subject = 'Password';
        $mail->Body    = 'Your passsword was <b>'.$password.'</b>';
        
        if($mail->send()){
            $SuccessLoginMsg = ['status'=>'200','message'=>'Password Sent Sucessfuly'];
            $SuccessLoginJson = json_encode($SuccessLoginMsg);
            echo $SuccessLoginJson ;
        }else{
            $MSG = ['status'=>'500','message'=>'Passsword Not Sent Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
        }
    } catch (Exception $e) {
            $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
    }

    
}else{
    $InvalidMSG = ['status'=>'500','message'=>'Email id is not registered with us Please try with different it'];
    $InvalidMSGJSon = json_encode($InvalidMSG);
    echo $InvalidMSGJSon ;
}
 
mysqli_close($con);
?>