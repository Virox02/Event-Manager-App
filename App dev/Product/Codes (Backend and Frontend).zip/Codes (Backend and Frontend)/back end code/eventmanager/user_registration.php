<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception; 


require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
include 'dbconfig.php';

$mail = new PHPMailer(true);


$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
$name = $obj['name'];
$email = $obj['email'];
$password = $obj['password'];

$class = $obj['class'];
$section = $obj['section'];
$phone = $obj['phone'];
$role = $obj['role'];
$type = $obj['type'];
$otp = rand ( 10000 , 99999 );

//$MSG = "name is ".$name." email is ".$email." password is ".$password." class is ".$class." section is ".$section." phone is ".$phone." role is".$role." type is".$type." and otp is".$otp;
// $a = 'asd';
// die;

$CheckSQL = "SELECT * FROM user WHERE email='$email' AND is_delete=0";
$check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
 
 
if(isset($check)){
    $EmailExistMSG = ['status'=>'500','message'=>'Email Already Exist, Please Try Again !'];
    $EmailExistJson = json_encode($EmailExistMSG);
    echo $EmailExistJson ; 
 
}else{
    
    if($type == '2'){
        $CheckTeacherSql = "SELECT * FROM teacher_email WHERE teacherEmail='$email'";
        $CheckTeacher = mysqli_fetch_array(mysqli_query($con,$CheckTeacherSql));
        if(!empty($CheckTeacher)){
            $Sql_Query = "insert into user (name,email,class,section,phone,password,role,otp,type) values ('$name','$email','$class','$section','$phone','$password','$role','$otp','$type')";
            if(mysqli_query($con,$Sql_Query)){

                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'virox0220@gmail.com';
                    $mail->Password   = 'virajrahil02';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port       = 465;
                
                    $mail->setFrom('virox0220@gmail.com', 'JPIS');
                    $mail->addAddress($email);
                    
                    $mail->isHTML(true);
                    $mail->Subject = 'User Registration OTP';
                    $mail->Body    = 'Hello thank you for registration, your OTP is <b>'.$otp.'</b>';
                    
                    if($mail->send()){
                        $Sql_Id = "select id from user where email = '$email'";
                        $user_id = mysqli_fetch_array(mysqli_query($con,$Sql_Id));
                        if(!empty($user_id)){
                            $userId = $user_id['id'];
                        }
                        $MSG = ['status'=>'200','message'=>'Teacher Registered Sucessfully','data'=>$userId];
                        $json = json_encode($MSG);
                        echo $json ;
                    }else{
                        $MSG = ['status'=>'500','message'=>'Teacher Not Added Please Try Again'];
                        $json = json_encode($MSG);
                        echo $json ;
                    }
                } catch (Exception $e) {
                        $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                        $json = json_encode($MSG);
                        echo $json ;
                }

            }else{
                $MSG = ['status'=>'500','message'=>'Teacher Not Added Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
            }        
        }else{
            $MSG = ['status'=>'500','message'=>'Teacher Email Address Not Registered Inside System'];
            $json = json_encode($MSG);
            echo $json ;
        }
    }else{
            $Sql_Query = "insert into user (name,email,class,section,phone,password,role,otp,type) values ('$name','$email','$class','$section','$phone','$password','$role','$otp','$type')";
            if(mysqli_query($con,$Sql_Query)){
                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'virox0220@gmail.com';
                    $mail->Password   = 'virajrahil02';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port       = 465;
                
                    $mail->setFrom('virox0220@gmail.com', 'JPIS');
                    $mail->addAddress($email);
                    
                    $mail->isHTML(true);
                    $mail->Subject = 'User Registration OTP';
                    $mail->Body    = 'Hello thakyou for registration, your one time passsword is <b>'.$otp.'</b>';
                    
                    if($mail->send()){
                        $Sql_Id = "select id from user where email = '$email'";
                        $user_id = mysqli_fetch_array(mysqli_query($con,$Sql_Id));
                        if(!empty($user_id)){
                            $userId = $user_id['id'];
                        }
                        $MSG = ['status'=>'200','message'=>'Student Registered Sucessfully','data'=>$userId];
                        $json = json_encode($MSG);
                        echo $json ;
                    }else{
                        $MSG = ['status'=>'500','message'=>'Student Not Added Please Try Again'];
                        $json = json_encode($MSG);
                        echo $json ;
                    }
                } catch (Exception $e) {
                        $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                        $json = json_encode($MSG);
                        echo $json ;
                }
            }else{
                $MSG = ['status'=>'500','message'=>'Student Not Added Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
            }        
        
    }
        
}
 mysqli_close($con);
?>