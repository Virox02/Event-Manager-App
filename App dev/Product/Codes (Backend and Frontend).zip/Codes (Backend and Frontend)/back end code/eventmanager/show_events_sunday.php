<?php
 
include 'dbconfig.php';
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
 

$type = $obj['type'];
$todayDate = '2019-09-10';
if($type == 'student'){
    $Sql_Query = "select * from events where start_date > '$todayDate'";
}else{
    $Sql_Query = "select * from events";
}
$result = $con->query($Sql_Query);
 
if ($result->num_rows >0) {
    
 
 while($row[] = $result->fetch_assoc()) {
 
 $item = $row;
 
 $json = json_encode($item);
 
 }
 
 
} else {
 echo "No Results Found.";
}
 echo $json;
// $conn->close();
// $check[] = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
// if(isset($check)){
//     $SuccessLoginMsg = ['status'=>'200','message'=>'Results found','data'=>$check];
//     $SuccessLoginJson = json_encode($SuccessLoginMsg);
//     echo $SuccessLoginJson ;    
// }else{
//     $InvalidMSG = ['status'=>'500','message'=>'No result found'];
//     $InvalidMSGJSon = json_encode($InvalidMSG);
//     echo $InvalidMSGJSon ;
// }
 
mysqli_close($con);
?>