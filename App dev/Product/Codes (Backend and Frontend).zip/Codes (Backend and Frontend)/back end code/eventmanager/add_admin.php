<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception; 


require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
include 'dbconfig.php';

$mail = new PHPMailer(true);


$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
$name = $obj['name'];
$email = $obj['email'];
$oldId = $obj['oldId'];
$password = rand ( 10000 , 99999 );

$class = 'NA';
$section = 'NA';
$phone = $obj['phone'];
$role = 'Admin';
$type = 3;
$otp = rand ( 10000 , 99999 );

//$MSG = "name is ".$name." email is ".$email." password is ".$password." class is ".$class." section is ".$section." phone is ".$phone." role is".$role." type is".$type." and otp is".$otp;
// $a = 'asd';
// die;

$CheckSQL = "SELECT * FROM user WHERE email='$email' AND is_delete=0";
$check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
 
 
if(isset($check)){
    $EmailExistMSG = ['status'=>'500','message'=>'Email Already Exist, Please Try Again !'];
    $EmailExistJson = json_encode($EmailExistMSG);
    echo $EmailExistJson ; 
 
}else{
    
        
            $Sql_Query = "insert into user (name,email,class,section,phone,password,role,otp,type,status,verified,is_delete) values ('$name','$email','$class','$section','$phone','$password','Admin','$otp','3','1','1','0')";
            if(mysqli_query($con,$Sql_Query)){

                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'virox0220@gmail.com';
                    $mail->Password   = 'virajrahil02';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port       = 465;
                
                    $mail->setFrom('virox0220@gmail.com', 'JPIS');
                    $mail->addAddress($email);
                    
                    $mail->isHTML(true);
                    $mail->Subject = 'New Admin Password';
                    $mail->Body    = 'Hello welcome to event manager of JPIS, your have been appointed as new admin your credentials is as follows email is <b>'.$email.'</b> and password is <b>'.$password.'</b>';
                    
                    if($mail->send()){
                        $Sql_Query = "UPDATE user SET is_delete='1' WHERE id='$oldId'";
                        if(mysqli_query($con,$Sql_Query)){
                            $MSG = ['status'=>'200','message'=>'Old Admin deleted and new added.'];
                            $json = json_encode($MSG);
                            echo $json ;
                        }
                    }else{
                        $MSG = ['status'=>'500','message'=>'Admin Not Added Please Try Again'];
                        $json = json_encode($MSG);
                        echo $json ;
                    }
                } catch (Exception $e) {
                        $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                        $json = json_encode($MSG);
                        echo $json ;
                }

            }else{
                $MSG = ['status'=>'500','message'=>'Admin Not Added Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
            }
}
 mysqli_close($con);
?>