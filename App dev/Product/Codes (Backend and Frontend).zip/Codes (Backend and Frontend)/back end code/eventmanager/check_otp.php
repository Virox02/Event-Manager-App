<?php
 
include 'dbconfig.php';
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
 

$id = $obj['id'];
$otp = $obj['otp'];


$Sql_Query = "select otp from user where id = '$id'";
$check = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
if(isset($check)){
    
    $dbOtp = $check['otp']; 
    if($otp == $dbOtp){
        $change_status = "UPDATE user SET verified = 1  where id = '$id' ";
        if(mysqli_query($con,$change_status)){
            $SuccessLoginMsg = ['status'=>'200','message'=>'Otp verified sucessfully'];
            $SuccessLoginJson = json_encode($SuccessLoginMsg);
            echo $SuccessLoginJson ;
        }else{
            $InvalidMSG = ['status'=>'500','message'=>'Server down, Please Try Again'];
            $InvalidMSGJSon = json_encode($InvalidMSG);
            echo $InvalidMSGJSon ;
        }
    }else{
        $InvalidMSG = ['status'=>'500','message'=>'Entered otp is not valid, Please Try with corrrect otp'];
        $InvalidMSGJSon = json_encode($InvalidMSG);
        echo $InvalidMSGJSon ;
    }
    
}else{
    $InvalidMSG = ['status'=>'500','message'=>'Email id is not registered with us Please Try Again'];
    $InvalidMSGJSon = json_encode($InvalidMSG);
    echo $InvalidMSGJSon ;
}
 
mysqli_close($con);
?>