<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception; 


require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
include 'dbconfig.php';

$mail = new PHPMailer(true);
 
// Creating connection.
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 
// Getting the received JSON into $json variable.
$json = file_get_contents('php://input');
 
// decoding the received JSON and store into $obj variable.
$obj = json_decode($json,true);
 
 // Populate User name from JSON $obj array and store into $name.
$title = $obj['title'];
 
// Populate User email from JSON $obj array and store into $email.
$description = $obj['description'];
 
// Populate Password from JSON $obj array and store into $password.
$fee = $obj['fee'];

$agegroup = $obj['agegroup'];
$venue = $obj['venue'];
$start_date = $obj['start_date'];
$end_date = $obj['end_date'];
 
//Checking Email is already exist or not using SQL query.
$CheckSQL = "SELECT * FROM events WHERE title='$title' AND is_delete=0";
 
// Executing SQL Query.
$check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
 
 
if(isset($check)){
 
 $EmailExistMSG = ['status'=>'500','message'=>'Event Already Exist, Please Try Again !!!'];
 
 // Converting the message into JSON format.
$EmailExistJson = json_encode($EmailExistMSG);
 
// Echo the message.
 echo $EmailExistJson ; 
 
 }
 else{
 
 // Creating SQL query and insert the record into MySQL database table.
$Sql_Query = "insert into events (title,description,fee,agegroup,venue,start_date,end_date) values ('$title','$description','$fee','$agegroup','$venue','$start_date','$end_date')";
 
if(mysqli_query($con,$Sql_Query)){
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'virox0220@gmail.com';
        $mail->Password   = 'virajrahil02';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;
    
        $mail->setFrom('virox0220@gmail.com', 'JPIS');
        $mail->addAddress('rahiljain.intelligence@gmail.com');
        
        $mail->isHTML(true);
        $mail->Subject = 'New event added';
        $mail->Body    = 'Hello Students a new event'.$title.' has been added please check the app and registered before'.$end_date;
        
        if($mail->send()){
            $MSG = ['status'=>'200','message'=>'Event Registered Sucessfully'];
            $json = json_encode($MSG);
            echo $json ;
        }else{
            $MSG = ['status'=>'500','message'=>'Event Not Added Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
        }
    } catch (Exception $e) {
            $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
    }
 // If the record inserted successfully then show the message.


 
 }
 else{
 
    $MSG = ['status'=>'500','message'=>'Event Not Added Please Try Again'];
    $json = json_encode($MSG);
    echo $json ;
 
 }
}
 mysqli_close($con);
?>