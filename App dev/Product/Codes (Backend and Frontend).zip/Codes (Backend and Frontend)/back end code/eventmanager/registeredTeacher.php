<?php
 
include 'dbconfig.php';
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);

$json = file_get_contents('php://input');
$obj = json_decode($json,true);
$type = $obj['type'];


$Sql_Query = "select * from user where type='$type' AND status != 0 AND is_delete = 0 AND verified = 1";
$result = $con->query($Sql_Query);
 
if ($result->num_rows >0) {
    
 
 while($row[] = $result->fetch_assoc()) {
 
 $item = $row;
 
 $json = json_encode($item);
 
 }
 
 
} else {
    $InvalidMSG = ['status'=>'500','message'=>'No Teacher found'];
    $InvalidMSGJSon = json_encode($InvalidMSG);
    echo $InvalidMSGJSon ;
}
 echo $json;

// $check = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
// if(isset($check)){
//     $SuccessLoginMsg = ['status'=>'200','message'=>'Showing results','data'=>$check];
//     $SuccessLoginJson = json_encode($SuccessLoginMsg);
//     echo $SuccessLoginJson ;
    
// }else{
//     $InvalidMSG = ['status'=>'500','message'=>'No student has registered yet'];
//     $InvalidMSGJSon = json_encode($InvalidMSG);
//     echo $InvalidMSGJSon ;
// }
 
mysqli_close($con);
?>