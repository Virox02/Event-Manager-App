<?php
 

include 'dbconfig.php';
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
$id = $obj['id'];

$CheckSQL = "SELECT * FROM user WHERE id='$id'";
$check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
if(empty($check)){
	$EmailExistMSG = ['status'=>'500','message'=>'Person does not exists'];
	$EmailExistJson = json_encode($EmailExistMSG);
	echo $EmailExistJson ; 
}else{
	$Sql_Query = "UPDATE user SET is_delete='1' WHERE id='$id'";
	
	if(mysqli_query($con,$Sql_Query)){
		$MSG = ['status'=>'200','message'=>'Removed Sucessfully'];
		$json = json_encode($MSG);
		echo $json ;
	}else{
		$InvalidMSG = ['status'=>'500','message'=>'Server down, Please Try Again'];
		$InvalidMSGJSon = json_encode($InvalidMSG);
		echo $InvalidMSGJSon ;
	}
}
mysqli_close($con);
?>