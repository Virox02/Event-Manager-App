<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception; 

require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
include 'dbconfig.php';
 
$mail = new PHPMailer(true);
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
 

$id = $obj['id'];

$Sql_Query = "select otp, email from user where id = '$id'";
$check = mysqli_fetch_array(mysqli_query($con,$Sql_Query));
if($check){
    $dbOtp = $check['otp'];  
    $email = $check['email'];  
}

if(isset($check)){

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'virox0220@gmail.com';
        $mail->Password   = 'virajrahil02';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;
    
        $mail->setFrom('virox0220@gmail.com', 'JPIS');
        $mail->addAddress($email);
        
        $mail->isHTML(true);
        $mail->Subject = 'User Registration OTP';
        $mail->Body    = 'Hello thakyou for registration, your one time passsword is <b>'.$dbOtp.'</b>';
        
        if($mail->send()){
            $SuccessLoginMsg = ['status'=>'200','message'=>'Otp Sent Sucessfuly'];
            $SuccessLoginJson = json_encode($SuccessLoginMsg);
            echo $SuccessLoginJson ;
        }else{
            $MSG = ['status'=>'500','message'=>'Otp Not Sent Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
        }
    } catch (Exception $e) {
            $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
            $json = json_encode($MSG);
            echo $json ;
    }

    
}else{
    $InvalidMSG = ['status'=>'500','message'=>'Email id is not registered with us Please try with different it'];
    $InvalidMSGJSon = json_encode($InvalidMSG);
    echo $InvalidMSGJSon ;
}
 
mysqli_close($con);
?>