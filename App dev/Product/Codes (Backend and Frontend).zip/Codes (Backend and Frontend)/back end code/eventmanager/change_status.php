<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception; 


require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';
include 'dbconfig.php';

$mail = new PHPMailer(true);

$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);

$id = $obj['table_id'];
$status = $obj['appr_status'];
$email = $obj['email'];

$change_status = "UPDATE event_registration SET status = '$status'  where id = '$id' ";
if(mysqli_query($con,$change_status)){
    if($status == 1){
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'virox0220@gmail.com';
            $mail->Password   = 'virajrahil02';
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;
        
            $mail->setFrom('virox0220@gmail.com', 'JPIS');
            $mail->addAddress($email);
            
            $mail->isHTML(true);
            $mail->Subject = 'Registration status';
            $mail->Body    = 'Thank you for registering, You are selected for the event. Please check the event details once more.';
            
            if($mail->send()){
                $MSG = ['status'=>'200','message'=>'Registration Approved Sucessfully'];
                $json = json_encode($MSG);
                echo $json ;
            }else{
                $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
            }
        } catch (Exception $e) {
                $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
        }
        
    }else if($status == 0){
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'virox0220@gmail.com';
            $mail->Password   = 'virajrahil02';
            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;
        
            $mail->setFrom('virox0220@gmail.com', 'JPIS');
            $mail->addAddress($email);
            
            $mail->isHTML(true);
            $mail->Subject = 'Registration status';
            $mail->Body    = 'Thank you for registering, But unfortunately you are not selected for the event.';
            
            if($mail->send()){
                $MSG = ['status'=>'200','message'=>'Registration Rejected Sucessfully'];
                $json = json_encode($MSG);
                echo $json ;
            }else{
                $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
            }
        } catch (Exception $e) {
                $MSG = ['status'=>'500','message'=>'Server down Please Try Again'];
                $json = json_encode($MSG);
                echo $json ;
        }
    }else{
        $message = 'Server Down please try again';
        $SuccessLoginMsg = ['status'=>'200','message'=>$message];
        $SuccessLoginJson = json_encode($SuccessLoginMsg);
        echo $SuccessLoginJson ;
    }
    
}else{
    $InvalidMSG = ['status'=>'500','message'=>'Server down, Please Try Again'];
    $InvalidMSGJSon = json_encode($InvalidMSG);
    echo $InvalidMSGJSon ;
}

mysqli_close($con);
?>