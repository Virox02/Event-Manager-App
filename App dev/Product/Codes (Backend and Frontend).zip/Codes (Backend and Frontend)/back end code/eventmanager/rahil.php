<?php
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = 'root';
    // print_r('aasda');
    // $conn = mysql_connect($dbhost, $dbuser, $dbpass);
    $connection = mysqli_connect('localhost','root','root') or die(mysql_error()); 
// print_r('a'.$connection);
// die;
    if(! $connection ) {
        die('Could not connect: ' . mysql_error());
    }
    echo 'Connected successfully';
    mysql_close($connection);
?>