<?php
 

include 'dbconfig.php';
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
$event_id = $obj['event_id'];
$user_id = $obj['user_id'];
$name = $obj['name'];
$email = $obj['email'];
$class = $obj['class'];
$section = $obj['section'];
$phone_no = $obj['phone_no'];
$intrest_reason = $obj['intrest_reason'];
$previous_achievement = $obj['previous_achievement'];

$CheckSQL = "SELECT * FROM event_registration WHERE event_id='$event_id' AND user_id='$user_id'";
$check = mysqli_fetch_array(mysqli_query($con,$CheckSQL));
if(isset($check)){
	$EmailExistMSG = ['status'=>'500','message'=>'Event registration has already been done by logged-in user against this event'];
	$EmailExistJson = json_encode($EmailExistMSG);
	echo $EmailExistJson ; 
}else{
	$Sql_Query = "insert into event_registration (event_id,user_id,name,email,class,section,phone_no,intrest_reason,previous_achievement) values ('$event_id','$user_id','$name','$email','$class','$section','$phone_no','$intrest_reason','$previous_achievement')";
	
	if(mysqli_query($con,$Sql_Query)){
		$MSG = ['status'=>'200','message'=>'Event Registered Successfully'];
		$json = json_encode($MSG);
		echo $json ;
	}else{
		$InvalidMSG = ['status'=>'500','message'=>'Server down, Please Try Again'];
		$InvalidMSGJSon = json_encode($InvalidMSG);
		echo $InvalidMSGJSon ;
	}
}
mysqli_close($con);
?>