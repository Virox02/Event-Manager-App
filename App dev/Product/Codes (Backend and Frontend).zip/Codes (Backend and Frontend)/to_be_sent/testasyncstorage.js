import { AppLoading } from 'expo';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import React, { useState, Component} from 'react';
import { Platform, StatusBar, StyleSheet, View,Text,Button,AsyncStorage,TouchableOpacity } from 'react-native';
import {createStackNavigator, createAppContainer,createSwitchNavigator} from 'react-navigation';
import {Login} from './screens/EVENT MANAGER 1ST SCREEN UI'
import {Home} from './screens/event app events screen' 

class checkscreen extends React.Component{
    componentWillMount(){
        this.checkToken();
    }
    checkToken = async () => {
        try {
          const value = await AsyncStorage.getItem('token')
          if(value !== null) {
            this.props.navigation.navigate('home');
          }else{
            this.props.navigation.navigate('login');
          }
        } catch(e) {
        }
      }
      render(){
        return(
          <View style={{backgroundColor:'red',flex:1}} />
        )
      }
    }
class Login extends React.Component(){
    setToken = async () => {
        try {
          await AsyncStorage.setItem('token', 'yes');
        } catch (error) {
          
        }
      };
      render(){
        return(
          < Login />


          
        )
      }
    }
class Home extends React.Component{
        render(){
          return(
            < Home />
          )
        }
    }











const start = createSwitchNavigator({
    check: {screen: checkscreen},
    login: {screen: Login},
    home: {screen: Home}

})

const evnt = createAppContainer(start)
export default evnt;



import { AppLoading } from 'expo';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import React, { useState, Component} from 'react';
import { Platform, StatusBar, StyleSheet, View,Text,Button,AsyncStorage,TouchableOpacity } from 'react-native';
import {createStackNavigator, createAppContainer,createSwitchNavigator} from 'react-navigation';
// import {Login} from './Login' if you are placing LoginScreen.js in the same folder in which app is placed
// import {Xyz} from './screens/Login' if you are placing LoginScreen.js in the screens folder in which app is placed
// import {Abc} from './screens/subscreen/Login' if you are placing LoginScreen.js in the screens folder in which app is placed

class home_screen extends React.Component{
  render(){
    return(
      <View style={{backgroundColor:'red',flex:1,justifyContent:'center',alignItems:'center'}}>
        <Text> Home Screen </Text>
      </View>
    )
  }
}

class login_screen extends React.Component{
  setToken = async () => {
    try {
      await AsyncStorage.setItem('token', 'yes');
    } catch (error) {
      // Error saving data
    }
  };
  render(){
    return(
      <View style={{backgroundColor:'blue',flex:1,justifyContent:'center',alignItems:'center'}}>
        <Text> Login Screen </Text>
        <TouchableOpacity onPress={() => this.setToken()}>
          <Text> Sign in </Text>
        </TouchableOpacity>
      </View>
      // <Xyz />
    )
  }
}

class welcome extends React.Component{
  // If we need to call a function we need to wrap it up either inside componentWillMount() or componentDidMount()
  // Diffence between them is componentWillMount will get called before the component get loaded on DOM amd componentDidMount will get called after compoent will get loaded on DOM
  // DOM :- Document Object Model :- In React Native all our component would get loaded on DOM , DOM is a tree structre on which our components placed
  // after exection RN DOM would get converted into native stuff
  componentWillMount(){
    this.checkToken();
  }
  checkToken = async () => {
    try {
      const value = await AsyncStorage.getItem('token')
      if(value !== null) {
        this.props.navigation.navigate('home');
      }else{
        this.props.navigation.navigate('login');
      }
    } catch(e) {
      // error reading value
    }
  }
  render(){
    return(
      <View style={{backgroundColor:'red',flex:1}} />
    )
  }
}

// Switch Navigator contains those screen from which user can not go back
// Generally these screens are Login Screen or Home Screen

// Now when the app starts app need to check whether to navigate a user to login screen or home screen
// And this will be done using Asyncstorage
// AsyncStorage is something that store a token inside app memory so everytime app start this token will get evaluated and if the value is present inside asyncstorage this will navigate to HomeScreen otherwise Login
// We will set the value of token after sucessfully login of a user.
const Startpoint = createSwitchNavigator({
  // routes : {screen:<Variable name of a component>}
  check:{screen:welcome},
  login:{screen:login_screen},
  home:{screen:home_screen}
})

const Viraj = createAppContainer(Startpoint)

export default Viraj;