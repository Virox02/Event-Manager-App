import { AppLoading } from 'expo';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import React, { useState, Component} from 'react';
import { Platform, StatusBar, StyleSheet, View,Text,Button,AsyncStorage,TouchableOpacity } from 'react-native';
import {createStackNavigator, createAppContainer,createSwitchNavigator} from 'react-navigation';
import {wel} from './screens/wel';
import {login} from './screens/login';
import {Home} from './screens/Home';
import {SignUpStudent} from './screens/SignUpStudent';
import {SignInStud} from './screens/SignInStud';
import {Forgotpassword} from './screens/Forgotpassword';
import {RegistrationForm} from './screens/RegistrationForm';
import {SignUpTeacher} from './screens/SignUpTeacher';

// import React, {Component} from 'react';
// import {createSwitchNavi

const loginstacknavigator = createStackNavigator({
  signin: {screen:login},
  signup: {screen: SignInStud},
  forget: {screen: Forgotpassword},
})

const Homestacknavigator = createStackNavigator({
  landing: {screen: Home},
  form: {screen: RegistrationForm}  
})

const AppSwitchNavigator = createSwitchNavigator({
  login: {screen: loginstacknavigator},
  home: {screen: Homestacknavigator}
  
})
  
const AppContainer = createAppContainer(AppSwitchNavigator);

export default (AppContainer);
