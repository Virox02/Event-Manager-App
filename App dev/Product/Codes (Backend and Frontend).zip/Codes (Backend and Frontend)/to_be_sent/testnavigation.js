import { AppLoading } from 'expo';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import React, { useState, Component} from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity,FlatList} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {createStackNavigator, createAppContainer} from 'react-navigation';

class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'Home Screen',
  };
  render() {
    const {navigate} = this.props.navigation;
    return (
      <View style = {{flex:1, marginTop: 20, backgroundColor: 'white'}}>
      
        
          <View style={{flex:2 }}>
            <View style = {{flex:1.5, paddingTop: 20}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 30}}>
                Event Manager App
              </Text>
              
            </View>
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20}}>
            <View style = {{flex: 1}}>
              <TextInput
              style = {{height: 80, borderBottomColor: 'black', borderBottomWidth: 1}}
              placeholder = 'ENTER E-MAIL'
              />
              <TextInput
              style = {{height:80, borderBottomColor: 'black', borderBottomWidth: 1}}

              placeholder = 'ENTER PASSWORD'
              secureTextEntry = {true}
              />
            </View>
            <TouchableOpacity onPress={() => navigate('Profile')} style = {{flex: 0.4, justifyContent: 'center', alignItems: 'center', backgroundColor: 'skyblue', borderRadius: 30}}>
              <Text style = {{fontSize: 20,fontWeight:'bold'}}>
                LOG IN
              </Text>
              
            </TouchableOpacity>

          </View>
          <View style={{flex:1}}>
          <TouchableOpacity style={{flex:1, alignItems: 'flex-end', justifyContent: 'center', paddingRight: 26}}>
            <Text style = {{fontSize: 16, color: 'red'}}>
              Forgot Password?
            </Text>
          </TouchableOpacity>
          <View style={{flexDirection: 'row',flex:2}}>
            <View style = {{flex: 2, justifyContent: 'center', alignItems: 'flex-end'}}>
              <Text style = {{fontSize: 20}}>
                Don't have an account? 
              </Text>
            </View>
            <TouchableOpacity style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start',paddingLeft:5}}>
              <Text style = {{fontSize: 20,fontWeight:'bold'}}>
                Sign Up  
              </Text>
              </TouchableOpacity>
              </View>
          </View>
      </View>
        
      
    );
  }
}

class ProfileScreen extends React.Component {
  render() {
    const { navigation } = this.props;
    return (
      <View style = {{flex:1, marginTop: 20, backgroundColor: 'black'}}>
        
    <View style={{paddingTop:5}}>
      <FlatList
  data={
        [
          {eventname: 'MUN',fees:'1500',startdate:'June 15,2019',enddate:'June 21,2019', description: 'asdfghjkloiuytresdfghjkftftgfck', venue: 'jpis', agegroup: '9th-12th'},
          {eventname: 'Dance',fees:'1200',startdate:'June 25,2019',enddate:'July 02,2019', description: 'asdfghjkloiuytresdfghjkftftgfck', venue: 'jpis', agegroup: '9th-12th'},
          {eventname: 'flairfest', fees: '0', startdate: 'july 6, 2019', enddate: 'july 20, 2019', description: 'asdfghjkloiuytresdfghjkftftgfck', venue: 'jpis', agegroup: '9th-12th'}
          
        ]
        }
  renderItem={
      ({item}) => <TouchableOpacity style = {{flex: 1, backgroundColor: 'white', marginTop: 10, marginLeft: 10, marginRight: 10, height: 250}}>
      
          <ImageBackground style = {{flex: 1, flexDirection: 'column'}}
          source = {item.image}
    
        >
            <View style = {{flex: 1,  justifyContent: 'center', alignItems: 'center'}}>
              <Text style = {{fontSize: 36, fontWeight: 'bold', color: 'black'}}>
                {item.eventname}
              </Text>
            </View>
            <View style = {{flex: 3,  flexDirection: 'row'}}>
              <View style = {{flex:1, borderRightWidth: 1, borderRightColor: 'black'}}>
                <Text style = {{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  DESCRIPTION:-
                  {item.description}
                </Text>
              </View>
              <View style = {{flex: 1, justifyContent: 'space-around'}}>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  FEE - {item.fees}
                </Text>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  VENUE - {item.venue}
                </Text>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  AGE GROUP - {item.agegroup}
                </Text>
              </View>
            </View>
            <View style = {{flex: 1, flexDirection: 'row'}}>
              <View style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                <Text style = {{fontSize: 14,  fontWeight: 'bold', color: 'black'}}>
                  start date- {item.startdate}
                </Text>
              </View>
              
              <View style = {{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                <Text style = {{fontSize: 14,  fontWeight: 'bold', color: 'black'}}>
                   end date - {item.enddate}
                </Text>
              </View>
              
              
            </View>
          </ImageBackground>
        </TouchableOpacity>
      }
      ItemSeparatorComponent={this.renderSeparator}
/>
</View>
</View>
    );
  }
}



const MainNavigator = createStackNavigator({
  Home: {screen: HomeScreen},
  Profile: {screen: ProfileScreen},

});

const App = createAppContainer(MainNavigator);

export default App;

