import React, {Component} from 'react';
import {Text, View,TouchableOpacity} from 'react-native';

export class wel extends Component {
    render(){
        return(
            <View style = {{marginTop: 20}}>
                
                    <Text>Check Login</Text>
                
            </View>
        )
    }
}
