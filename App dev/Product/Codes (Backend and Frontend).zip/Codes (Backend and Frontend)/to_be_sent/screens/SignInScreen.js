import React, { Component } from 'react';
import { StyleSheet,Modal, View,NativeModules, Text,Alert,Platform, Image, TextInput, TouchableOpacity,KeyboardAvoidingView,TouchableHighlight, Button} from 'react-native';


class SignInScreen extends Component {
    constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '', 
      userPassword: '',
      modalVisible: false
    }
  }
  static navigationOptions = {
    header: null
  }
  
  navigatetohome = () => {
    if(this.state.UserEmail == '' || this.state.userPassword == ''){
      alert('username and password has to be filled')
    } else {
      let email = 'viraj@gmail.com';
      let password = '12345';
        if(this.state.UserEmail == email && this.state.userPassword == password){
          this.props.navigation.navigate('home')
        } else{
          alert('wrong email or/and password')
        }
     // checking if email is exists
     // if not then show user does not exists inside database
     // if yes then reterving its password from db
     // if retervied password and this.state.userPassword gets matched then navigate to home screen
     // if not then show alert message 
    }
    teacherNavigate = () => {
      alert('sdds')
    }
    return false;
    this.props.navigation.navigate('home');
  }
    render(){
    return (
      <View style = {{flex:1, marginTop: 20, backgroundColor: 'white'}}>
          <View style={{flex:2 }}>
            <View style = {{flex:1.5, paddingTop: 20}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 30}}>
                Event Manager App
              </Text>
              
            </View>
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20}}>
            <View style = {{flex: 1}}>
              <TextInput
              style = {{height: 80, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'ENTER E-MAIL'
              />
              <TextInput
              style = {{height:80, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userPassword => this.setState({userPassword})}
              placeholder = 'ENTER PASSWORD'
              secureTextEntry = {true}
              />
            </View>
            <TouchableOpacity onPress={() => this.navigatetohome()} style = {{flex: 0.4, justifyContent: 'center', alignItems: 'center', backgroundColor: 'skyblue', borderRadius: 30}}>
              <Text style = {{fontSize: 20,fontWeight:'bold'}}>
                LOG IN
              </Text>
              
            </TouchableOpacity>

          </View>
          <View style={{flex:1}}>
          <TouchableOpacity onPress = {() => this.props.navigation.push('forget')} style={{flex:1, alignItems: 'flex-end', justifyContent: 'center', paddingRight: 26}}>
            <Text style = {{fontSize: 16, color: 'red'}}>
              Forgot Password?
            </Text>
          </TouchableOpacity>
          <View style={{flexDirection: 'row',flex:2}}>
            <View style = {{flex: 2, justifyContent: 'center', alignItems: 'flex-end'}}>
              <Text style = {{fontSize: 20}}>
                Don't have an account? 
              </Text>
            </View>
            <TouchableOpacity onPress = {() => this.setModalVisible(true)} style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start',paddingLeft:5}}>
              <Text style = {{fontSize: 20,fontWeight:'bold'}}>
                Sign Up  
              </Text>
              </TouchableOpacity>
              </View>
          </View>
         
      </View>
    );
    }
}

export default SignInScreen;
