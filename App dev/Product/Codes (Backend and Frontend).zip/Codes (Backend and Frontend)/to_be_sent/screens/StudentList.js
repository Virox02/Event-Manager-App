import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity,FlatList} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';

export default class StudentList extends React.Component {

  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '',
      userFirstName:'',
      mobile:'',
      stud_class:'',
      section:'',
      reason_of_intrest:'',
      prev_achi:'',
      eventName:'',
      eventDesc:'',
      eventStartdt:'',
      eventEnddt:'',
      spinner: false,
      JSON_data:[]
    }
  }
  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
  }

  componentDidMount(){
    
    this.getparamData();

  }

  getparamData =  async () => {
    this.showHideSpinner(true);
    global.name = await this.props.navigation.getParam('name');
    global.description = await this.props.navigation.getParam('description');
    global.startdate = await this.props.navigation.getParam('startdate');
    global.enddate = await this.props.navigation.getParam('enddate');
    global.userIdToken = await this.props.navigation.getParam('userIdToken');
    global.type = await this.props.navigation.getParam('type');
    global.eventId = await this.props.navigation.getParam('eventId');
    
    this.setState({
      eventName:global.name,
      eventDesc:global.description,
      eventStartdt:global.startdate,
      eventEnddt:global.enddate,
    })

    return fetch(helpers.baseUrl+'registrationStudent.php',{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        event_id: global.eventId
     
      })
     
    }).then((response) => response.json())
          .then((responseJson) => {
            this.setState({
              JSON_data : responseJson
            })
            this.showHideSpinner(false);
          }).catch((error) => {
            this.showHideSpinner(false);
            alert(`server is down please try again`)
          });
  }

  studentinfo = async (item) => {
    
    const { navigation } = this.props;
    global.userIdToken = await navigation.getParam('userIdToken');
    
    this.props.navigation.push('Selection',{
      name:global.name,
      description:global.description,
      startdate:global.startdate,
      enddate:global.enddate,
      username:item.name,
      email:item.email,
      class:item.class,
      phone_no:item.phone_no,
      intrest_reason:item.intrest_reason,
      previous_achievement:item.previous_achievement,
      id:item.id,
      status:item.status,
      type:global.type
    })
  }

renderSeparator = () => (
    <View
      style={{
        backgroundColor: 'red',
        height: 0.5,
      }}
    />
  );

  render() {
    console.log(this.state.JSON_data);
    return (
       <View style = {{flex:1, marginTop: 20, backgroundColor: 'brown'}}>
       <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        
    <View style={{paddingTop:20}}>
      <FlatList
  data={this.state.JSON_data}
  renderItem={
      ({item}) => 
      <TouchableOpacity onPress={()=>this.studentinfo(item)} style = {{height: 40, backgroundColor: 'skyblue', flexDirection: 'row', justifyContent: 'space-around'}}>
        <View style = {{flex: 5, alignItems: 'flex-start', justifyContent: 'center', paddingLeft: 10}}>
          <Text style = {{ color:'red',textAlign: 'left'}}> {item.name}</Text>
        </View>
        <View style = {{flex:5, justifyContent: 'center', alignItems: 'flex-end'}}>
                  <Text style = {{ }}>{item.class} </Text>
        </View>
        <View style = {{flex:1,justifyContent: 'center', alignItems: 'flex-start'}}>
                  <Text style = {{}}>{item.section}</Text>
        </View>
                  </TouchableOpacity>
      }
      ItemSeparatorComponent={this.renderSeparator}
      keyExtractor={(item, index) => index.toString()}
/>
</View>
</View>
    );
  }
}