import React, { Component } from 'react';
import { View,Text,TextInput,TouchableOpacity,Image } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import helpers from './helpers';

class Otp extends Component {

    constructor(props){
        super(props);
        
        this.state = {
          UserEmail: '', 
          userOtp: ''
        }
    }
    componentDidMount(){
        this.getparamdata();
    }
    getparamdata = async () => {
        global.email = await this.props.navigation.state.params.UserEmail;
        
    }
    otp = () =>{
        // alert('please confirm your otp & verify yourself')
        // this.props.navigation.navigate('Otp')
        // return false;
        console.log(`otp is ${this.state.userOtp} and email is ${global.email}`);
       
        return fetch(helpers.baseUrl+'check_otp.php',{
              
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: global.email,
              otp:this.state.userOtp
            })
          
          }).then((response) => response.json())
                .then((responseJson) => {
                    alert(responseJson.message);
                    this.props.navigation.navigate('SigninScreen')
                }).catch((error) => {
                    alert(error);
                    this.props.navigation.navigate('SigninScreen')
                });
         
        }
    goToSignup = () => {
        this.props.navigation.navigate('SignUpChoice');
    }
    render(){
        return (
            <View style = {{flex:1, marginTop: 20, backgroundColor: 'white'}}>
                <View style={{flex:2 }}>
                    <View style = {{flex:1.5, paddingTop: 20}}>
                    
                    <View style = {{flex: 1}}>
                        <Image
                        source = {require('./jpisLogo.jpeg')}
                        style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                        />
                    
                    </View>

                    </View>
                    <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
                    <Text style = {{fontSize: 30}}>
                        Event Manager App
                    </Text>
                    
                    </View>
                    
                    
                </View>
                <View style={{flex:2, paddingRight: 20, paddingLeft:20}}>
                    <View style = {{flex: 1}}>
                    <TextInput
                    style = {{height: 80, borderBottomColor: 'black', borderBottomWidth: 1}}
                    onChangeText = {userOtp => this.setState({userOtp})}
                    placeholder = 'ENTER OTP'
                    />
                    </View>
                    <TouchableOpacity onPress={() => this.otp()} style = {{flex: 0.4, justifyContent: 'center', alignItems: 'center', backgroundColor: 'skyblue', borderRadius: 30}}>
                    <Text style = {{fontSize: 20,fontWeight:'bold'}}>
                        Submit
                    </Text>
                    
                    </TouchableOpacity>

                </View>
            </View>
        )
    }
}
export default Otp;