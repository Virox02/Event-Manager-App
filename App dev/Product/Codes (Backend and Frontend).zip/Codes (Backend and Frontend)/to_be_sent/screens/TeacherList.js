import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity,FlatList} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';

export default class TeacherList extends React.Component {

  constructor(props){
    super(props);
    
    this.state = {
      spinner: false,
      JSON_data:[]
    }
  }
  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
  }

  componentDidMount(){
    
    this.getparamData();

  }

  getparamData =  async () => {

    
    const { navigation } = this.props;
    global.type = await navigation.getParam('type');
    console.log(global.type);
    this.showHideSpinner(true);

    return fetch(helpers.baseUrl+'registeredTeacher.php',{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type:global.type,
      })
     
    }).then((response) => response.json())
          .then((responseJson) => {
            this.setState({
              JSON_data : responseJson,
              /* body: JSON.stringify({
                event_id: global.eventId
             
              }) */
            })
            this.showHideSpinner(false);
          }).catch((error) => {
            this.showHideSpinner(false);
            alert(`server is down please try again`)
          });
  }

  teacherinfo = async (item) => {
    const { navigation } = this.props;
    global.userIdToken = await navigation.getParam('userIdToken');
    
    this.props.navigation.push('Viewteacher',{
      name:item.name,
      email:item.email,
      role:item.role,
      phone:item.phone,
      userId:item.id,
      type:global.type,
      phone_no:item.phone
    })
  }

renderSeparator = () => (
    <View
      style={{
        backgroundColor: 'red',
        height: 0.5,
      }}
    />
  );

  render() {
    console.log(this.state.JSON_data);
    return (
       <View style = {{flex:1, marginTop: 20, backgroundColor: 'brown'}}>
       <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        
    <View style={{paddingTop:20}}>
      <FlatList
  data={this.state.JSON_data}
  renderItem={
      ({item}) => 
      <TouchableOpacity onPress={()=>this.teacherinfo(item)} style = {{height: 40, backgroundColor: 'skyblue', flexDirection: 'row', justifyContent: 'space-around'}}>
        <View style = {{flex: 5, alignItems: 'flex-start', justifyContent: 'center', paddingLeft: 10}}>
          <Text style = {{ color:'blue',textAlign: 'left'}}> {item.name}</Text>
        </View>
        <View style = {{flex:2,justifyContent: 'center', alignItems: 'flex-start'}}>
                  <Text style = {{}}>{item.role}</Text>
        </View>
                  </TouchableOpacity>
      }
      ItemSeparatorComponent={this.renderSeparator}
      keyExtractor={(item, index) => index.toString()}
/>
</View>
</View>
    );
  }
}