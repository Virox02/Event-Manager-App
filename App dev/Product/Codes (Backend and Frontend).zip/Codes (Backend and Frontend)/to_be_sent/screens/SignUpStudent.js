import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image,Alert, Button, ImageBackground, TouchableOpacity} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import helpers from './helpers';


class SignUpStudent extends React.Component {

  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '', 
      userPassword: '',
      userFirstName:'',
      userConfirmPassword:'',
      mobile:'',
      userclass:'',
      usersection:'',
      spinner: false
    }
}

showHideSpinner(visible) {
  this.setState({spinner: visible}); 
}

studentSignup = () =>{
  
  // return false;
  console.log(`phone is ${this.state.mobile}`);


  this.showHideSpinner(true);
        return fetch(helpers.baseUrl+'user_registration.php',{
         method: 'POST',
         headers: {
           'Accept': 'application/json',
           'Content-Type': 'application/json',
         },
         body: JSON.stringify({
        
          name: this.state.userFirstName,
    
          email: this.state.UserEmail,
      
          password: this.state.userConfirmPassword,
  
          phone: this.state.mobile,
  
          class: this.state.userclass,
  
          section: this.state.usersection,
  
          role: 'student',
  
          type: '1',

          otp: '1891',
        
         })
        
       }).then((response) => response.json())
             .then((responseJson) => {
                if(responseJson.status == 200){
                    this.showHideSpinner(false);
                    alert(responseJson.message + ' Please confirm your otp & verify yourself');
                    
                    this.props.navigation.navigate('Otp',{
                      UserEmail:responseJson.data
                    })
                    // this.props.navigation.navigate('SigninScreen')
                }else{
                    this.showHideSpinner(false);
                    alert(responseJson.message);
                }
             }).catch((error) => {
              this.showHideSpinner(false);
               alert(`server is down please try again`)
             });
 
   
   
  }
  
  render() {
    return (
      <View style = {{flex:1}}
      
      >
        <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        <View style={{flex:0.7 }}>
            <View style = {{flex:1.5, paddingTop: 2}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 26, color: 'green'}}>
                Student Sign-Up
              </Text>
              
            </View>
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20, flexDirection: 'column' }}>
          
            <View style = {{flex: 1, justifyContent: 'center'}}>
              <TextInput
              style = {{height: 50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userFirstName => this.setState({userFirstName})}
              placeholder = 'FULL NAME'
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'E-MAIL'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {mobile => this.setState({mobile})}
              placeholder = 'PHONE NO.'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userclass => this.setState({userclass})}
              placeholder = 'CLASS'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {usersection => this.setState({usersection})}
              placeholder = 'SECTION'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userPassword => this.setState({userPassword})}
              placeholder = 'PASSWORD'
              secureTextEntry = {true}
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userConfirmPassword => this.setState({userConfirmPassword})}
              placeholder = 'CONFIRM PASSWORD'
              secureTextEntry = {true}
              />

            </View>
            <View style = {{flex: 0.2, paddingLeft: 30, paddingRight: 30}}>
              <TouchableOpacity onPress={() => this.studentSignup()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'black', borderRadius: 20}}>
                <Text style = {{fontSize: 28, fontWeight: 'bold', color: 'white'}}>
                  SIGN UP
                </Text>
                
              </TouchableOpacity>
            </View>

          </View>
          


            

          
      </View>
    );
  }
}

export default SignUpStudent;