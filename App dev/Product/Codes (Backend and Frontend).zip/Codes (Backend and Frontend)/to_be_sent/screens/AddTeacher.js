import  * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';

export default class AddTeacher extends React.Component {
  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '',
      userFirstName:'',
      mobile:'',
      spinner: false
    }
  }

  componentDidMount(){
    this.getparamdata();
  }

  getparamdata = async () => {
    global.userIdToken = await this.props.navigation.state.params.addedBy;
    global.type = await this.props.navigation.state.params.type;
      // alert(`${global.userIdToken} and ${global.type}`)
  }

  showHideSpinner(visible) {
        this.setState({spinner: visible}); 
  }

  addTeach = () => {
    this.showHideSpinner(true);
    return fetch(helpers.baseUrl+'teacher_email.php',{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        teacherEmail: this.state.UserEmail,
        addedBy: global.userIdToken
     
      })
     
    }).then((response) => response.json())
          .then((responseJson) => {
             if(responseJson.status == 200){
                 this.showHideSpinner(false);
                 alert(`Email added sucessfully`);
                 this.props.navigation.push('Home',{
                     type:`${global.type}`,
                     userIdToken:`${global.userIdToken}`
                 })
             }else{
                 this.showHideSpinner(false);
                 alert(responseJson.message);
             }
          }).catch((error) => {
            alert(`server is down please try again`)
          });
  }
  render() {
    return (
      <View style = {{flex:1}}
      
      >
      <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        
          <View style={{flex:1 }}>
            <View style = {{flex:1.5}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 30}}>
                Event Manager App
              </Text>
              
            </View>
            
           
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20, flexDirection: 'column' }}>
          <Text style = {{fontSize: 22, color: 'orange'}}>
                ADD TEACHER
              </Text>
            <View style = {{flex: 1, justifyContent: 'center'}}>
              <TextInput
              style = {{height: 50, borderBottomColor: 'black', borderBottomWidth: 1}}
              placeholder = 'Tecaher Name'
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'E-mail'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}

              placeholder = 'PHONE NO.'
              
              />
              

            </View>
            <View style = {{flex: 0.2, paddingLeft: 30, paddingRight: 30}}>
              <TouchableOpacity onPress={()=>this.addTeach()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'black', borderRadius: 20}}>
                <Text style = {{fontSize: 28, fontWeight: 'bold', color: 'white'}}>
                  ADD
                </Text>
                
              </TouchableOpacity>
            </View>

          </View>
          


            

          
      </View>
    );
  }
}