import * as React from 'react';
import { Text, View, TouchableOpacity, ScrollView} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';


export default class Viewteacher extends React.Component {
  constructor(props){
    super(props);
    
    this.state = {
        name: '',
        email:'',
      role:'',
      phone_no:'',
      userId:'',
      spinner: false,

    }
  }
  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
  }

  componentDidMount(){
    
    this.getparamData();

  }


  getparamData =  async () => {
    const { navigation } = this.props;
    global.name = await navigation.getParam('name');
    global.email = await navigation.getParam('email');
    global.role = await navigation.getParam('role');
    global.phone_no = await navigation.getParam('phone_no');
    global.userId = await navigation.getParam('userId');
    global.type = await navigation.getParam('type');
    
    // alert(`${global.name} ${global.description} ${global.startdate} ${global.enddate}`);
    // alert(`${global.username} ${global.email} ${global.class} ${global.phone_no} ${global.intrest_reason}`)
    
    this.setState({
      name:global.name,
      email:global.email,
      role:global.role,
      phone_no:global.phone_no,
      userId:global.userId,
    })
    
  }

  changeAppr = () => {
    if(global.type == 3){
      this.props.navigation.push('Addadmin',{
        userId:global.userId,
        type:global.type
      })
      
    }else{
    this.showHideSpinner(true);
    return fetch(helpers.baseUrl+'delete_user.php',{
      method: 'POST',
      headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          id:this.state.userId,

      })
      
      }).then((response) => response.json())
          .then((responseJson) => {
              if(responseJson){
                  alert(JSON.stringify(responseJson.message));
                  this.showHideSpinner(false);
                  // AsyncStorage.setItem('user', JSON.stringify(responseJson.data.id))
                  // AsyncStorage.setItem('type', JSON.stringify(responseJson.data.type))
                  this.props.navigation.navigate('Home');
              }else{
                alert(JSON.stringify(responseJson))
              }
          }).catch((error) => {
              this.showHideSpinner(false);
              alert(error.toString());
          });
        }
  }
  
  render() {
// console.log('>>>>>>>>>>>>>>>>>');
// console.log(this.state.appr_status);
    let addteacher = (
      <View style = {{marginTop:15,marginBottom: 10, flex: 0.115, paddingLeft: 5, paddingRight: 5, flexDirection: 'row'}}>
        <TouchableOpacity onPress={()=>this.changeAppr()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'red', borderRadius: 20, paddingLeft: 10 }}>
          <Text style = {{fontSize: 26}}>
            Delete
          </Text>
          
        </TouchableOpacity>
      </View>
    );

    return (
      
      <View > 
        <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        <ScrollView>
          <View style = {{ flex: 2}}>
            <View style = {{ backgroundColor: 'grey', flex:2 }}>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
                DETAILS:- 
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
              Name : {this.state.name}
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
              Email : {this.state.email}
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
              Role : {this.state.role}
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
              Phone : {this.state.phone_no}
              </Text>
            </View>
          </View>
          <View style = {{ flex:3}}>
            {addteacher
            //   (this.state.appr_status == '3') ? addteacher : null
            }
          </View>
        </ScrollView>
      </View>

    );
  }
}

/* CREATE TABLE `user_events` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `name` varchar(100) NOT NULL,
 `email` varchar(100) NOT NULL,
 `password` varchar(250) NOT NULL,
 `class` int(11) DEFAULT NULL,
 `section` varchar(100) DEFAULT NULL,
 `role_in_school` varchar(100) DEFAULT 'NA',
 `type` int(11) NOT NULL DEFAULT '1',
 `status` int(11) NOT NULL DEFAULT '0',
 `otp` int(11) DEFAULT NULL,
 PRIMARY KEY (`id`)
) */3