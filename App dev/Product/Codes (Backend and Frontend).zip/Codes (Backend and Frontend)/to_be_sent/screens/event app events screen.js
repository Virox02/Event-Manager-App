import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity,FlatList} from 'react-native';

export default class App extends React.Component {



  render() {
    return (
       <View style = {{flex:1, marginTop: 20, backgroundColor: 'black'}}>
        
    <View style={{paddingTop:5}}>
      <FlatList
  data={
        [
          {eventname: 'MUN',fees:'1500',startdate:'June 15,2019',enddate:'June 21,2019', description: 'asdfghjkloiuytresdfghjkftftgfck', venue: 'jpis', agegroup: '9th-12th'},
          {eventname: 'Dance',fees:'1200',startdate:'June 25,2019',enddate:'July 02,2019', description: 'asdfghjkloiuytresdfghjkftftgfck', venue: 'jpis', agegroup: '9th-12th'},
          {eventname: 'flairfest', fees: '0', startdate: 'july 6, 2019', enddate: 'july 20, 2019', description: 'asdfghjkloiuytresdfghjkftftgfck', venue: 'jpis', agegroup: '9th-12th'}
          
        ]
        }
  renderItem={
      ({item}) => <TouchableOpacity style = {{flex: 1, backgroundColor: 'white', marginTop: 10, marginLeft: 10, marginRight: 10, height: 250}}>
      
          <ImageBackground style = {{flex: 1, flexDirection: 'column'}}
          source = {item.image}
    
        >
            <View style = {{flex: 1,  justifyContent: 'center', alignItems: 'center'}}>
              <Text style = {{fontSize: 36, fontWeight: 'bold', color: 'black'}}>
                {item.eventname}
              </Text>
            </View>
            <View style = {{flex: 3,  flexDirection: 'row'}}>
              <View style = {{flex:1, borderRightWidth: 1, borderRightColor: 'black'}}>
                <Text style = {{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  DESCRIPTION:-
                  {item.description}
                </Text>
              </View>
              <View style = {{flex: 1, justifyContent: 'space-around'}}>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  FEE - {item.fees}
                </Text>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  VENUE - {item.venue}
                </Text>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  AGE GROUP - {item.agegroup}
                </Text>
              </View>
            </View>
            <View style = {{flex: 1, flexDirection: 'row'}}>
              <View style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                <Text style = {{fontSize: 14,  fontWeight: 'bold', color: 'black'}}>
                  start date- {item.startdate}
                </Text>
              </View>
              
              <View style = {{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                <Text style = {{fontSize: 14,  fontWeight: 'bold', color: 'black'}}>
                   end date - {item.enddate}
                </Text>
              </View>
              
              
            </View>
          </ImageBackground>
        </TouchableOpacity>
      }
      ItemSeparatorComponent={this.renderSeparator}
/>
</View>
</View>
    );
  }
}