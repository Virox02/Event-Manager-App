import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity, ScrollView} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';
import AsyncStorage from '@react-native-community/async-storage';


export default class selection extends React.Component {
  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '',
      userFirstName:'',
      mobile:'',
      stud_class:'',
      section:'',
      reason_of_intrest:'',
      prev_achi:'',
      appr_status:'0',
      eventName:'',
      eventDesc:'',
      eventStartdt:'',
      eventEnddt:'',
      spinner: false,

    }
  }
  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
  }

  componentDidMount(){
    
    this.getparamData();

  }
  

  getparamData =  async () => {
    const { navigation } = this.props;
    global.type = await navigation.getParam('type');
    global.name = await navigation.getParam('name');
    global.id = await navigation.getParam('id');
    global.description = await navigation.getParam('description');
    global.startdate = await navigation.getParam('startdate');
    global.enddate = await navigation.getParam('enddate');
    global.username = await navigation.getParam('username');
    global.email = await navigation.getParam('email');
    global.class = await navigation.getParam('class');
    global.phone_no = await navigation.getParam('phone_no');
    global.intrest_reason = await navigation.getParam('intrest_reason');
    global.previous_achievement = await navigation.getParam('previous_achievement');
    global.status = await navigation.getParam('status');
    // alert(global.type)
    // alert(JSON.stringify(AsyncStorage.getItem('id')));
    // alert(`${global.name} ${global.description} ${global.startdate} ${global.enddate}`);
    // alert(`${global.username} ${global.email} ${global.class} ${global.phone_no} ${global.intrest_reason}`)
    
    this.setState({
      eventName:global.name,
      eventDesc:global.description,
      eventStartdt:global.startdate,
      eventEnddt:global.enddate,
      appr_status:global.status,
    })
    
  }

  changeAppr = (status) => {
    if(global.type != '2'){
      alert('Sorry only teacher has access to change status');
      return false;
    }
    this.showHideSpinner(true);
    return fetch(helpers.baseUrl+'change_status.php',{
      method: 'POST',
      headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        // table_id:
          appr_status: status,
          email:global.email,
          table_id:id

      })
      
      }).then((response) => response.json())
          .then((responseJson) => {
              if(responseJson){
                  alert(JSON.stringify(responseJson.message));
                  this.showHideSpinner(false);
                  // AsyncStorage.setItem('user', JSON.stringify(responseJson.data.id))
                  // AsyncStorage.setItem('type', JSON.stringify(responseJson.data.type))
                  this.props.navigation.navigate('Home');
              }else{
                alert(JSON.stringify(responseJson))
              }
          }).catch((error) => {
              this.showHideSpinner(false);
              alert(error.toString());
          });

  }
  
  render() {
// console.log('>>>>>>>>>>>>>>>>>');
// console.log(this.state.appr_status);
    let addteacher = (
      <View style = {{marginTop:15,marginBottom: 10, flex: 0.115, paddingLeft: 5, paddingRight: 5, flexDirection: 'row'}}>
        <TouchableOpacity onPress={()=>this.changeAppr('1')} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'green', borderRadius: 20, paddingRight: 5}}>
          <Text style = {{fontSize: 26}}>
            APPROVE
          </Text>
          
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>this.changeAppr('0')} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'red', borderRadius: 20, paddingLeft: 10 }}>
          <Text style = {{fontSize: 26}}>
            DISAPPROVE
          </Text>
          
        </TouchableOpacity>
      </View>
    );

    return (
      
      <View > 
        <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        <ScrollView>
          <View style = {{ flex: 2}}>
            <View style = {{backgroundColor: 'black', flex: 1}}>
              <View style = {{flex:1, backgroundColor: 'black', justifyContent: 'center', alignItems: 'center'}}>
                <Text style = {{fontSize: 40, fontWeight: 'bold', color: 'white'}}>
                  
                </Text>
              </View>
              
              

            </View>
            <View style = {{ backgroundColor: 'grey', flex:2 }}>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
                DETAILS:- 
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
                {global.description}
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
                {global.startdate}
              </Text>
              <Text style = {{fontSize: 18, paddingTop : 10, paddingLeft: 5, color: 'black'}}>
                {global.enddate}
              </Text>
            </View>
          </View>
          <View style = {{ flex:3}}>
            <View style = {{flex:0.13, backgroundColor: 'white', justifyContent: 'center', alignItems : 'center'}}>
              <Text style = {{fontSize: 38, color: 'black'}}>
                FORM Values
              </Text>
            </View>
            <View style = {{flex: 1, justifyContent: 'space-evenly', paddingLeft: 10, paddingRight: 10, backgroundColor: 'white'}}>
              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
               Name :- {global.username}
              </Text>

              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
               Email :-  {global.email}
              </Text>

              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
                Phone :- {global.phone_no}
              </Text>

              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
                Class :-  {global.class}
              </Text>

              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
                Section :-  A
              </Text>
              
              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
                Reason :-  {global.intrest_reason}
              </Text>

              <Text
              style = {{height: 40, borderBottomColor: 'black', borderBottomWidth: 1}}
              >
                Previous Aachievements :-  {global.previous_achievement}
              </Text>

            </View>
            {
              (this.state.appr_status == '2') ? addteacher : null
            }
          </View>
        </ScrollView>
      </View>

    );
  }
}

/* CREATE TABLE `user_events` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `name` varchar(100) NOT NULL,
 `email` varchar(100) NOT NULL,
 `password` varchar(250) NOT NULL,
 `class` int(11) DEFAULT NULL,
 `section` varchar(100) DEFAULT NULL,
 `role_in_school` varchar(100) DEFAULT 'NA',
 `type` int(11) NOT NULL DEFAULT '1',
 `status` int(11) NOT NULL DEFAULT '0',
 `otp` int(11) DEFAULT NULL,
 PRIMARY KEY (`id`)
) */