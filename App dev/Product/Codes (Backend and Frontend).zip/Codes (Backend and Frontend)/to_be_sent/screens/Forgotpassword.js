import React, {Component} from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity } from 'react-native';
import helpers from './helpers';
export default class Forgotpassword extends Component {


  forgetPassword =() => {
      return fetch(helpers.baseUrl+'forget_password1.php',{
      method: 'POST',
      headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'x_rest_username':'admin@restuser',
          'x_rest_password':'admin@Access',
          'x_rest_version':'v1'
      },
      body: JSON.stringify({
          email: this.state.UserEmail

      })
      
      }).then((response) => response.json())
          .then((responseJson) => {
              if(responseJson){
                alert('A mail has been sent to you, please follow instruction.')
                this.props.navigation.navigate('SigninScreen');
                  // AsyncStorage.setItem('user', JSON.stringify(responseJson.data.id))
                  // AsyncStorage.setItem('type', JSON.stringify(responseJson.data.type))
                  // this.props.navigation.navigate('HomeAppScreen');
              }else{
                alert(JSON.stringify(responseJson))
              }
          }).catch((error) => {
              // this.showHideSpinner(false);
              alert(error.toString());
          });
  }

  render() {
    return (
      <View style = {{flex:1}}
      
      >
        
        <View style={{flex:0.7 }}>
            <View style = {{flex:1.5, paddingTop: 2}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 26, color: 'green'}}>
                Student Sign-Up
              </Text>
              
            </View>
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20, flexDirection: 'column' }}>
          
            <View style = {{flex: 1, justifyContent: 'center'}}>
              
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'E-MAIL'
              
              />

            </View>
            <View style = {{flex: 0.2, paddingLeft: 30, paddingRight: 30}}>
              <TouchableOpacity onPress={() => this.forgetPassword()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'black', borderRadius: 20}}>
                <Text style = {{fontSize: 28, fontWeight: 'bold', color: 'white'}}>
                  Forgot password
                </Text>
                
              </TouchableOpacity>
            </View>

          </View>
          


            

          
      </View>
    )
  }
}