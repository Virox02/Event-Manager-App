import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity, ScrollView} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';

class RegistrationForm extends React.Component {

  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '',
      userFirstName:'',
      mobile:'',
      stud_class:'',
      section:'',
      reason_of_intrest:'',
      prev_achi:'',
      eventName:'',
      eventDesc:'',
      eventStartdt:'',
      eventEnddt:'',
      spinner: false
    }
  }

  componentDidMount(){
    
    this.getparamData();

  }

  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
}

  getparamData =  async () => {
    global.name = await this.props.navigation.getParam('name');
    global.description = await this.props.navigation.getParam('description');
    global.startdate = await this.props.navigation.getParam('startdate');
    global.enddate = await this.props.navigation.getParam('enddate');
    global.eventId = await this.props.navigation.getParam('eventId');
    global.type = await this.props.navigation.getParam('type');
    global.userIdToken = await this.props.navigation.getParam('userIdToken');
    this.setState({
      eventName:global.name,
      eventDesc:global.description,
      eventStartdt:global.startdate,
      eventEnddt:global.enddate,
    })
  }

  regis= () => {
    console.log(`Email is ${this.state.UserEmail} name is ${this.state.userFirstName} phone number is ${this.state.mobile} class is ${this.state.stud_class} section is ${this.state.section} intrest reason is ${this.state.reason_of_intrest} previous achi ${this.state.prev_achi} event id is ${global.eventId} and user id token is ${global.userIdToken}`)
    
    this.showHideSpinner(true);
    return fetch(helpers.baseUrl+'event_registration.php',{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
          email: this.state.UserEmail,
          name: this.state.userFirstName,
          phone_no:this.state.mobile,
          class:this.state.stud_class,
          section:this.state.section,
          intrest_reason:this.state.reason_of_intrest,
          previous_achievement:this.state.prev_achi,
          event_id:global.eventId,
          user_id:global.userIdToken,
     
      })
     
    }).then((response) => response.json())
          .then((responseJson) => {
             if(responseJson.status == 200){
                 this.showHideSpinner(false);
                 alert(responseJson.message)
                 this.props.navigation.push('Home',{
                     type:`${global.type}`,
                     userIdToken:`${global.userIdToken}`
                 })
             }else{
                 this.showHideSpinner(false);
                 alert(responseJson.message);
             }
          }).catch((error) => {
            this.showHideSpinner(false);
            alert(`server is down please try again`)
          });
}
  
  render() {
    return (
      
      <View> 
      <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        <ScrollView>
          <View style = {{ flex: 2}}>
            <View style = {{backgroundColor: 'black', flex: 1}}>
              <View style = {{flex:1, backgroundColor: 'black', justifyContent: 'center', alignItems: 'center'}}>
                <Text style = {{fontSize: 40, fontWeight: 'bold', color: 'white'}}>
                  {this.state.eventName}
                </Text>
              </View>
              
              

            </View>
            <View style = {{ backgroundColor: 'grey',justifyContent:'space-evenly', flex:2}}>
              <Text style = {{fontSize: 18,  paddingLeft: 5, color: 'black'}}>
                DETAILS:- 
              </Text>
              <Text style = {{fontSize: 18,  paddingLeft: 5, color: 'black'}}>
                {global.description}
              </Text>
              <Text style = {{fontSize: 18, paddingLeft: 5, color: 'black'}}>
                {global.startdate}
              </Text>
              <Text style = {{fontSize: 18, paddingLeft: 5, color: 'black'}}>
                {global.enddate}
              </Text>
            </View>
          </View>
          <View style = {{ flex:3}}>
            <View style = {{flex:0.13, backgroundColor: 'white', justifyContent: 'center', alignItems : 'center'}}>
              <Text style = {{fontSize: 38, color: 'black'}}>
                FORM
              </Text>
            </View>
            <View style = {{flex: 1, justifyContent: 'space-evenly', paddingLeft: 10, paddingRight: 10, backgroundColor: 'white'}}>
              <TextInput
              style = {{borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userFirstName => this.setState({userFirstName})}
              placeholder = 'FULL NAME'
              />
              <TextInput
              style = {{borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'E-MAIL'
              
              />
              <TextInput
              style = {{borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {mobile => this.setState({mobile})}
              placeholder = 'PHONE NO.'
              
              />
              <TextInput
              style = {{borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {stud_class => this.setState({stud_class})}
              placeholder = 'CLASS'
              
              />
              <TextInput
              style = {{borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {section => this.setState({section})}
              placeholder = 'SECTION'
              
              />
              <TextInput
              style = {{borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {reason_of_intrest => this.setState({reason_of_intrest})}
              placeholder = 'WHY ARE YOU INTERESTED?'
              
              />
              <TextInput
              style = {{ borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {prev_achi => this.setState({prev_achi})}
              placeholder = 'PREVIOUS EXPERINECE/ ACHIEVEMENTS'
              
              />

            </View>
            <View style = {{marginTop:15,marginBottom: 10, flex: 0.2, paddingLeft: 30, paddingRight: 30, backgroundColor: 'white'}}>
            <TouchableOpacity onPress={()=>this.regis()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'skyblue', borderRadius: 20}}>
              <Text style = {{fontSize: 28, fontWeight: 'bold'}}>
                SUBMIT
              </Text>
              
            </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>

    );
  }
}

export default RegistrationForm;