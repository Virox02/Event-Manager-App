import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';

class SignUpTeacher extends React.Component {

  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '', 
      userPassword: '',
      userFirstName:'',
      userConfirmPassword:'',
      mobile:'',
      roleinschool:'',
      spinner: false
    }
  }
  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
  }
    teacherSignup = () =>{
    // alert('please confirm your otp & verify yourself')
    // this.props.navigation.navigate('Otp')
    // return false;
    // console.log(`phone is ${this.state.mobile} name is ${this.state.userFirstName}, 
    //password is ${this.state.userConfirmPassword} phone is ${this.state.mobile}`);
   
  this.showHideSpinner(true);
  return fetch(helpers.baseUrl+'user_registration.php',{
   method: 'POST',
   headers: {
     'Accept': 'application/json',
     'Content-Type': 'application/json',
   },
   body: JSON.stringify({
  
    name: this.state.userFirstName,

    email: this.state.UserEmail,

    password: this.state.userConfirmPassword,

    phone: this.state.mobile,

    class: 'NA',

    section: 'NA',

    role: this.state.roleinschool,

    type: '2',

    otp: '1891',
  
   })
  
 }).then((response) => response.json())
       .then((responseJson) => {
          if(responseJson.status == 200){
              this.showHideSpinner(false);
              alert(responseJson.message + ' Please confirm your otp & verify yourself');    
              this.props.navigation.navigate('Otp',{
                UserEmail:responseJson.data
              })
              // alert(responseJson.message);
              // this.props.navigation.navigate('SigninScreen')
          }else{
              this.showHideSpinner(false);
              alert(responseJson.message);
          }
       }).catch((error) => {
        this.showHideSpinner(false);
         alert(`server is down please try again`)
       });

  }


  render() {
    return (
      <View style = {{flex:1, marginTop: 20}}
      
      >
      <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)' />
          <View style={{flex:1 }}>
            <View style = {{flex:1.5, paddingTop: 20}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 30}}>
                Event Manager App
              </Text>
              
              
            </View>
            
           
            
            
          </View>
            
          <View style={{flex:2, paddingRight: 20, paddingLeft:20, flexDirection: 'column' }}>
          <Text style = {{fontSize: 22, color: 'red'}}>
                Teacher Sign-up
              </Text>
            <View style = {{flex: 1, justifyContent: 'space-evenly'}}>
              <TextInput
              style = {{height: 50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userFirstName => this.setState({userFirstName})}
              placeholder = 'FULL NAME'
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'E-MAIL'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {mobile => this.setState({mobile})}
              placeholder = 'PHONE NO.'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {roleinschool => this.setState({roleinschool})}
              placeholder = 'ROLE IN SCHOOL'
              
              />
              
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userPassword => this.setState({userPassword})}
              placeholder = 'PASSWORD'
              secureTextEntry = {true}
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userConfirmPassword => this.setState({userConfirmPassword})}
              placeholder = 'CONFIRM PASSWORD'
              secureTextEntry = {true}
              />

            </View>
            <View style = {{flex: 0.2, paddingLeft: 30, paddingRight: 30}}>
              <TouchableOpacity onPress={() => this.teacherSignup()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'black', borderRadius: 20}}>
                <Text style = {{fontSize: 28, fontWeight: 'bold', color: 'white'}}>
                  SIGN UP
                </Text>
                
              </TouchableOpacity>
            </View>

          </View>
      </View>
    );
  }
}

export default SignUpTeacher;