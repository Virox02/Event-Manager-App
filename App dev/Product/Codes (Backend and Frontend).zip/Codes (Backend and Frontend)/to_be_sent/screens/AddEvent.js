import * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import helpers from './helpers';
class AddEvent extends React.Component {

  constructor(props){
    super(props);
    
    this.state = {
      title: '',
      description:'',
      fee:'',
      classes:'',
      venue:'',
      startdate:'',
      enddate:'',
      spinner: false
    }
  }

  componentDidMount(){
    this.getparamdata();
  }

  getparamdata = async () => {
    global.userIdToken = await this.props.navigation.state.params.addedBy;
    global.type = await this.props.navigation.state.params.type;
      // alert(`${global.userIdToken} and ${global.type}`)
  }

  showHideSpinner(visible) {
        this.setState({spinner: visible}); 
  }

  addevent = () => {

          return fetch(helpers.baseUrl+'event_list.php',{
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              title: this.state.title,
              description: this.state.description,
              fee:this.state.fee,
              agegroup:this.state.classes,
              venue:this.state.venue,
              start_date:this.state.startdate,
              end_date:this.state.enddate
           
            })
           
          }).then((response) => response.json())
                .then((responseJson) => {
                   if(responseJson.status == 200){
                       this.showHideSpinner(false);
                       alert(`Event added sucessfully`);
                       this.props.navigation.push('Home',{
                           type:`${global.type}`,
                           userIdToken:`${global.userIdToken}`
                       })
                   }else{
                       this.showHideSpinner(false);
                       alert(responseJson.message);
                   }
                }).catch((error) => {
                  alert(`server is down please try again`)
                });
  }

  render() {
    return (
      <View style = {{flex:1, marginTop: 20}}
      
      >
      <Spinner
            visible={this.state.spinner}
            overlayColor='rgba(0, 0, 0, 0.50)'
        />
        
        <View style={{flex:0.7 }}>
            <View style = {{flex:1.5, paddingTop: 2}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 26, color: 'black'}}>
                ADD EVENT
              </Text>
              
            </View>
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20, flexDirection: 'column' }}>
            <View style = {{flex: 1, justifyContent: 'center'}}>
              <TextInput
              onChangeText = {title => this.setState({title})}
              style = {{height: 50, borderBottomColor: 'black', borderBottomWidth: 1}}
              placeholder = 'EVENT TITLE'
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {description => this.setState({description})}
              placeholder = 'DESCRIPTION'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {fee => this.setState({fee})}
              placeholder = 'FEE'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {classes => this.setState({classes})}
              placeholder = 'CLASSES'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {venue => this.setState({venue})}
              placeholder = 'VENUE'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {startdate => this.setState({startdate})}
              placeholder = 'START DATE'
              
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {enddate => this.setState({enddate})}
              placeholder = 'END DATE'
              
              />

            </View>
            <View style = {{flex: 0.2, paddingLeft: 30, paddingRight: 30}}>
            <TouchableOpacity onPress={()=>this.addevent()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'skyblue', borderRadius: 20}}>
              <Text style = {{fontSize: 24}}>
                ADD
              </Text>
              
            </TouchableOpacity>
            </View>

          </View>

          


            

          
      </View>
    );
  }
}
export default AddEvent;