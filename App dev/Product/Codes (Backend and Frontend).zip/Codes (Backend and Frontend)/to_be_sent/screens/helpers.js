const helpers = {
    baseUrl:'http://157.245.100.198/eventmanager/'
}

export default helpers;
