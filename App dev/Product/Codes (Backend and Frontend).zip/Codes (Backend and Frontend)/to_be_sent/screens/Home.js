import * as React from 'react';
import { Text, View, TouchableOpacity,FlatList} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';
import AsyncStorage from '@react-native-community/async-storage';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

class Home extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      dummyText:'EVENTS',
      type:"2",
      JSON_data:[],
      spinner: false
    }
  }
  showHideSpinner(visible) {
    this.setState({spinner: visible}); 
}
  componentDidMount(){
    this.getparamdata();
  }
  getparamdata = async () => {
    this.showHideSpinner(true);
    const { navigation } = this.props;
    global.userIdToken = await navigation.getParam('userIdToken');
    global.type = await navigation.getParam('type');
    this.setState({
      type:global.type
    })
    // alert(`${global.userIdToken} and ${global.type}`);
    
    
    return fetch(helpers.baseUrl+'show_events.php',{
              
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: global.type,
      })
    
    }).then((response) => response.json())
          .then((responseJson) => {
           
              this.setState({
                JSON_data:responseJson
              })
              this.showHideSpinner(false);
           
          }).catch((error) => {
            this.showHideSpinner(false);
            alert(`Server is down please try again`);
          });
      
  }
  static navigationOptions = {
    header:null
  }
  deleteItem = (item) => {
    // console.log('>>>>>>>>>>>>>>');
    // console.log(item);
    // return false;
    return fetch(helpers.baseUrl+'delete_event.php',{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: item
      })
    }).then((response) => response.json())
      .then((responseJson) => {
        alert(responseJson.message);
        this.getparamdata();
      }).catch((error) => {
        console.error(error);
      });
  }
  navigationtoform = (item) => {
    if(this.state.type == 1){
      this.props.navigation.push('RegistrationForm',{
        name:item.title,
        description:item.description,
        startdate:item.start_date,
        enddate:item.end_date,
        eventId:item.id,
        userIdToken:global.userIdToken,
        type:global.type,
      })
    }else{
      this.props.navigation.push('StudentList',{
        name:item.title,
        description:item.description,
        startdate:item.start_date,
        enddate:item.end_date,
        userIdToken:global.userIdToken,
        eventId:item.id,
        type:global.type,
      })
    }
    
    return false;
    this.props.navigation.push('form',{
        name:item.eventname,
        description:item.description,
        startdate:item.startdate,
        enddate:item.enddate
      })
  }
  viewTeacher = (type) => {
    console.log('>>>>>>>>>>>>>>>>>>ssss');
    console.log(type);
    this.props.navigation.push('TeacherList',{
      type:type
    })
  }
  addTeacher = () => {
    this.props.navigation.push('AddTeacher',{
      addedBy:global.userIdToken,
      type:global.type,
    })
  }

  addEvents = () => {
    this.props.navigation.navigate('AddEvent',{
      addedBy:global.userIdToken,
      type:global.type,
    })
  }
  logOut = () => {
    AsyncStorage.clear();
    this.props.navigation.push('SigninScreen');
  }
  render() {
console.log(this.state.JSON_data);
    let addteacher = (
      <TouchableOpacity onPress={()=>this.addTeacher()} style={{flex:1,justifyContent:'center',alignItems:'center'}}>
          <Text style={{color:'yellow',  fontSize: 17}}>Add Teacher</Text>
        </TouchableOpacity>
    );

    let addevents = (
      <TouchableOpacity onPress={()=>this.addEvents()} style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text style={{color:'yellow', fontSize: 17}}>Add Events</Text>
        </TouchableOpacity>
    );

    let viewteacher = (
      <TouchableOpacity onPress={()=>this.viewTeacher('2')} style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text style={{color:'yellow', fontSize: 17}}>View Teacher</Text>
        </TouchableOpacity>
    );
    let viewAdmin = (
      <View style={{height:hp('5%'),backgroundColor:'black',justifyContent:'center',alignItems:'flex-start',paddingLeft:15}}>
        <TouchableOpacity onPress={()=>this.viewTeacher('3')} style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text style={{color:'yellow', fontSize: 17}}>View Admin</Text>
        </TouchableOpacity>
      </View>
      
    );
    return (
      <View style = {{flex: 1}}>
        <Spinner
          visible={this.state.spinner}
          overlayColor='rgba(0, 0, 0, 0.50)'
        />
        <View style={{height:hp('5%'),backgroundColor:'black',justifyContent:'center',alignItems:'flex-end',paddingRight:15}}>
          <TouchableOpacity onPress={()=>this.logOut()}>
            <Text style={{color:'white',fontSize:16}}>Logout</Text>
          </TouchableOpacity>
        </View>

        {
          (this.state.type == 3) ? viewAdmin : null
        }
        
        
                
        <View style={{height:hp('5%'),backgroundColor:'black',flexDirection:'row',justifyContent:'space-between',alignItems:'center'}}>

        {
          (this.state.type == 3) ? addteacher : null
        }
          
          
          <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text style={{color:'white', fontWeight: 'bold', fontSize: 20}}>EVENTS</Text>
          </View>
{/* 

if type will be 3 then view teacher, 
view teacher would be a seprate function like student list 
On click of navigationtoform screen will be like Registration form but only with detail
*/}
          {
          (this.state.type == 2) ? addevents : null
        }
        {
          (this.state.type == 3) ? viewteacher : null
        }
          
        </View>
        <View>
          <FlatList
            data={this.state.JSON_data}
            renderItem={
              ({item}) => <TouchableOpacity onPress={() => this.navigationtoform(item)} style = {{flex: 1,borderBottomColor:'grey',borderBottomWidth:1, backgroundColor: 'white', marginTop: 10, marginLeft: 10, marginRight: 10, height: 250}}>
      
         
            <View style = {{flex: 1,flexDirection:'row',justifyContent: 'center', alignItems: 'center'}}>
              <View style = {{flex: 4,justifyContent: 'center', alignItems: 'flex-start'}}>
                <Text style = {{fontSize: 36, fontWeight: 'bold', color: 'black'}}>
                  {item.title.substring(0,10)}..
                </Text>
              </View>
              
              {
                (this.state.type == 2) ? <View style = {{flex: 1,justifyContent: 'center', alignItems: 'flex-end'}}>
                
                <TouchableOpacity 
                  onPress={() => this.deleteItem(item.id)} >
                <Text style = {{fontSize: 20, color: 'red'}}>
                  Delete
                </Text>
                </TouchableOpacity>
              </View> : null
              }

              
              
            </View>
            <View style = {{flex: 3,  flexDirection: 'row'}}>
              <View style = {{flex:1, borderRightWidth: 1, borderRightColor: 'black'}}>
                <Text style = {{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Short description:-
                  {item.description.substring(0,100)}...
                </Text>
              </View>
              <View style = {{flex: 1, justifyContent: 'space-around'}}>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  FEE - {item.fee}
                </Text>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  VENUE - {item.venue.substring(0,15)}...
                </Text>
                <Text style = {{fontSize: 18, paddingLeft: 10,  fontWeight: 'bold', color: 'black'}}>
                  AGE GROUP - {item.agegroup.substring(0,15)}...
                </Text>
              </View>
            </View>
            <View style = {{flex: 1, flexDirection: 'row'}}>
              <View style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                <Text style = {{fontSize: 14,  fontWeight: 'bold', color: 'black'}}>
                  start date- {item.start_date}
                </Text>
              </View>
              
              <View style = {{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                <Text style = {{fontSize: 14,  fontWeight: 'bold', color: 'black'}}>
                   end date - {item.end_date}
                </Text>
              </View>
              
              
            </View>
          
        </TouchableOpacity>
      }
      ItemSeparatorComponent={this.renderSeparator}
      keyExtractor={(item,index) => index.toString()}
/>
</View>
</View>
    );
  }
}
export default Home;