import  * as React from 'react';
import { Text, View, StyleSheet,TextInput, Image, Button, ImageBackground, TouchableOpacity} from 'react-native';
import helpers from './helpers';
import Spinner from 'react-native-loading-spinner-overlay';
import AsyncStorage from '@react-native-community/async-storage';

export default class Addadmin extends React.Component {
  constructor(props){
    super(props);
    
    this.state = {
      UserEmail: '',
      userFirstName:'',
      mobile:'',
      spinner: false
    }
  }

  componentDidMount(){
    this.getparamdata();
  }

  getparamdata = async () => {
    global.userIdToken = await this.props.navigation.state.params.userId;
    global.type = await this.props.navigation.state.params.type;
      
  }

  showHideSpinner(visible) {
        this.setState({spinner: visible}); 
  }

  addTeach = () => {
    this.showHideSpinner(true);
    return fetch(helpers.baseUrl+'add_admin.php',{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name : this.state.userFirstName,
        email : this.state.UserEmail,        
        phone : this.state.mobile,        
        oldId : global.userIdToken        
      })
     
    }).then((response) => response.json())
          .then((responseJson) => {
             if(responseJson.status == 200){
                 this.showHideSpinner(false);
                 alert(`${responseJson.message}`);
                AsyncStorage.clear();
                this.props.navigation.push('SigninScreen');
             }else{
                 this.showHideSpinner(false);
                 console.log(responseJson.message);
             }
          }).catch((error) => {
            alert(`server is down please try again`)
          });
  }
  render() {
    return (
      <View style = {{flex:1}}
      
      >
      <Spinner
                    visible={this.state.spinner}
                    overlayColor='rgba(0, 0, 0, 0.50)'
                />
        
          <View style={{flex:1 }}>
            <View style = {{flex:1.5}}>
              
              <View style = {{flex: 1}}>
                <Image
                  source = {require('./jpisLogo.jpeg')}
                  style = {{height:'100%', width: '100%', resizeMode: 'contain'}}
                />
            
              </View>

            </View>
            <View style = {{flex:1, justifyContent: 'space-around', alignItems: 'center', backgroundColor: 'white'}}>
              <Text style = {{fontSize: 30}}>
                Event Manager App
              </Text>
              
            </View>
            
           
            
            
          </View>
          <View style={{flex:2, paddingRight: 20, paddingLeft:20, flexDirection: 'column' }}>
          <Text style = {{fontSize: 22, color: 'orange'}}>
                ADD Admin
              </Text>
            <View style = {{flex: 1, justifyContent: 'center'}}>
              <TextInput
              style = {{height: 50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {userFirstName => this.setState({userFirstName})}
              placeholder = 'Admin Name'
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {UserEmail => this.setState({UserEmail})}
              placeholder = 'E-mail'
              onChangeText = {UserEmail => this.setState({UserEmail})}
              />
              <TextInput
              style = {{height:50, borderBottomColor: 'black', borderBottomWidth: 1}}
              onChangeText = {mobile => this.setState({mobile})}
              placeholder = 'PHONE NO.'
              
              />
              

            </View>
            <View style = {{flex: 0.2, paddingLeft: 30, paddingRight: 30}}>
              <TouchableOpacity onPress={()=>this.addTeach()} style = {{marginBottom: 5, flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'black', borderRadius: 20}}>
                <Text style = {{fontSize: 28, fontWeight: 'bold', color: 'white'}}>
                  ADD
                </Text>
                
              </TouchableOpacity>
            </View>

          </View>
          


            

          
      </View>
    );
  }
}