class Template extends Component {

    render () {
        return (
            <View style = {{flex: 1}}>
                <View style = {{flex:1.5, paddingTop: 20, flexDirection: 'row'}}>
                    <View style = {{flex: 1, backgroundColor: 'red'}}>

                    </View>
                    <View style = {{flex: 0.5, backgroundColor: 'pink'}}>
                        
                    </View>
                
                </View>
            </View>
        );
    }
}


